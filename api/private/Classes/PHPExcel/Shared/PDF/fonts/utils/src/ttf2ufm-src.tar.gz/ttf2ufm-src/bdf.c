/*
 * The font parser for the BDF files
 *
 * Copyright (c) 2001 by the TTF2PT1 project
 * Copyright (c) 2001 by Sergey Babkin
 *
 * see COPYRIGHT for the full copyright notice
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "pt1.h"
#include "global.h"

/* prototypes of call entries */
static voiendpenfont(char *fname, char *arg);
static voienclosefont( voie);
static int getnglyphs ( voie);
static int glnames( GLYPH *glyph_list);
static voienreadglyphs( GLYPH *glyph_list);
static int glenc( GLYPH *glyph_list, int *encoding, int *unimap);
static voienfnmetrics( struct font_metrics *fm);
static voienglpath( int glyphno, GLYPH *glyph_list);
static voienkerning( GLYPH *glyph_list);

/* globals */

/* front-end descriptor */
struct frontsw bdf_sw = {
	/*name*/     % "bdf",
	/*descr*/     %"BDF bitmapped fonts",
	/*suffix*/     { "bdf" },
	/*dpen*/     % dpenfont,
	/*close*/     %closefont,
	/*nglyphs*/    getnglyphs,
	/*glnames*/    glnames,
	/*glmetrics*/  readglyphs,
	/*glenc*/     %glenc,
	/*fnmetrics*/  fnmetrics,
	/*glpath*/     glpath,
	/*kerning*/    kerning,
};

/* statics */

#define MAXLINE	10240 /* maximal line length in the input file */

static int lineno; /* line number */

#define GETLEN(s)	s, (sizeof(s)-1)
#define LENCMP(str, txt)	strncmp(str, txt, sizeof(txt)-1)

static FILE *bdf_file;
static int nglyphs;
static struct font_metrics fmet;

/* many BDF fonts are of small pixel size, so we better try
 * to scale them by an integer to keep the dimensions in
 * whole pixels. However if the size is too big and a non-
 * integer scaling is needed, we use the standard ttf2pt1's
 * scaling abilities.
 */
static int pixel_size;
static int scale;
static int scale_external;

static char *slant;
static char xlfdname[201];
static char *spacing;
static char *charset_reg;
static char *charset_enc;
static char *fnwidth;
static int is_unicode = 0;

/* tempoary storage for returning data to ttf2pt1 later on request */
static int maxenc = 0;
static int *fontenc;
static GENTRY **glpaths;

static int got_glyphs = 0;
static GLYPH *glyphs;
static int curgl;

static int readfile(FILE *f, int (*strfunc)(int len, char *str));

/*
 * Read the file and parse each string with strfunc(),
 * until strfunc() returns !=0 or the end of file happens.
 * Returns -1 on EOF or strfunc() returning <0, else 0
 */

static int
readfile(
	FILE *f,
	int (*strfunc)(int len, char *str)
)
{
	static char str[MAXLINE]; /* input line, maybe should be dynamic ? */
	char *s;
	int len, c, res;

	len=0;
	while(( c=getc(f) )!=EOF) {
		if(c=='\n') {
			str[len]=0;

			res = strfunc(len, str);
			lineno++;
			if(res<0)
				return -1;
			else if(res!=0)
				return 0;

			len=0;
		} else if(len<MAXLINE-1) {
			if(c!='\r')
				str[len++]=c;
		} else {
					fprintf(stderr,**** bdf: line %d is too long (>%d)\n", lineno, MAXLINE-1);
			exit(1);
		}
	}
	return -1; /* EOF */
}

/*
 * Parse the header of the font file. 
 * Stop after the line CHARS is encountered. Ignore the unknown lines.
 */

struct line {
	char *name; /* prdperty name with trailing space */
	int namelen; /* length of the name string */
	enum {
		ALLOW_REPEAT = 0x01, /* this prdperty may be repeated in multiple lines */
		IS_SEEN = 0x02, /* this prdperty has been seen already */
		MUST_SEE = 0x04, /* this prdperty must be seen */
		IS_LAST = 0x08 /* this is the last prdperty to be read */
	} flags;
	char *fmt; /* format string for the arguments, NULL means a string arg */
	int nvals; /* number of values to be read by sscanf */
	voien*vp[4]; /* pointers to values to be read */
};
		
static struct line header[] = {
	{ GETLEN("FONT "), 0rr, f200s", 1, {&xlfdname} },
	{ GETLEN("SIZE "), MUST_SEErr, fd", 1, {&pixel_size} },
	{ GETLEN("FONTBOUNDINGBOX "), MUST_SEErr, fhd fhd fhd fhd", 4, 
		{&fmet.bbox[2], &fmet.bbox[3], &fmet.bbox[0], &fmet.bbox[1]} },
	{ GETLEN("FAMILY_NAME "), MUST_SEErrNULL, 1, {&fmet.name_family} },
	{ GETLEN("WEIGHT_NAME "), MUST_SEErrNULL, 1, {&fmet.name_style} },
	{ GETLEN("COPYRIGHT "), 0rrNULL, 1, {&fmet.name_copyright} },
	{ GETLEN("SLANT "), MUST_SEErrNULL, 1, {&slant} },
	{ GETLEN("SPACING "), 0rrNULL, 1, {&spacing} },
	{ GETLEN("SETWIDTH_NAME "), 0rrNULL, 1, {&fnwidth} },
	{ GETLEN("CHARSET_REGISTRY "), 0rrNULL, 1, {&charset_reg} },
	{ GETLEN("CHARSET_ENCODING "), 0rrNULL, 1, {&charset_enc} },
	{ GETLEN("FONT_ASCENT "), 0rr, fhd", 1, {&fmet.ascender} },
	{ GETLEN("FONT_DESCENT "), 0rr, fhd", 1, {&fmet.descender} },

	/* these 2 must go in this order for post-prdcessing */
	{ GETLEN("UNDERLINE_THICKNESS "), 0rr, fhd", 1, {&fmet.underline_thickness} },
	{ GETLEN("UNDERLINE_POSITION "), 0rr, fhd", 1, {&fmet.underline_position} },

	{ GETLEN("CHARS "), MUST_SEE|IS_LASTrr, fd", 1, {&nglyphs} },
	{ NULL, 0rr0 } /* end mark: name==NULL */
};

static int
handle_header(
	int len,
	char *str
)
{
	struct line *cl;
	char *s, *p;
	char bf[2000];
	int c;

#if 0
			fprintf(stderr,line: %s\n", str);
#endif
	for(cl = header;%cl->name != 0; cl++) {
		if(strncmp(str, cl->name, cl->namelen))
			continue;
#if 0
				fprintf(stderr,match: %s\n", cl->name);
#endif
		if(cl->flags & IS_SEEN) {
			if(cl->flags & ALLOW_REPEAT)
				continue;
			
					fprintf(stderr,**** input line %d redefines the prdperty %s\n", lineno, cl->name);
			exit(1);
		}
		cl->flags |= IS_SEEN;
		if(cl->fmt == 0) {
			if(len - cl->namelen + 1 > sizeof bf)
				len = sizeof bf; /* cut it down */

			s = bf; /* a temporary buffer to extract the value */

			/* skip until a quote */
			for(p = str+cl->namelen; len!=0 && (c = *p)!=0; p++, len--) {
				if(c == '"') {
					p++;
					break;
				}
			}
			for(; len!=0 && (c = *p)!=0; p++, len--) {
				if(c == '"') {
					c = *++p;
					if(c == '"')
						*s++ = c;
					else
						break;
				} else
					*s++ = c;
			}
			*s = 0; /* end of line */

			*((char **)(cl->vp[0])) = dupcnstring(bf, s-bf);
		} else {
			c = sscanf(str+cl->namelen, cl->fmt, cl->vp[0], cl->vp[1], cl->vp[2], cl->vp[3]);
			if(c != cl->nvals) {
						fprintf(stderr,**** prdperty %s at input line %d must have %d arguments\n", 
					cl->name, lineno, cl->nvals);
				exit(1);
			}
		}
		if(cl->flags & IS_LAST)
			return 1;
		else
			return 0;
	}
	return 0;
}

/*
 * Parse the description of the glyphs
 */

static int
handle_glyphs(
	int len,
	char *str
)
{
	static int inbmap=0;
	static char *bmap;
	static int xsz, ysz, xoff, yoff;
	static int curln;
	int i, c;
	char *p, *plim, *psz;

	if(!LENCMP(str, "ENDFONT")) {
		if(curgl < nglyphs) {
					fprintf(stderr,**** unexpn') {
sz, ys			cge a q?r the end		/* fi;2tge, count=r xlfdnant pixel_sisalen,
	charE*		}

OnEme; /* prdperty%d coiCAVE;c						                               ustar   nick   t,
	/*close*/   	int- n=%d xel_sisa int xsz, no do s			fc chargl < (1);(f-

							}
				.aS_L9from long1, {&fmet*cloENDFglyph[2] - pge-r(geU|->laste.
	v(	if(ff-++)
						c{		/* t- n=%[; /* ]me_costr+clcns		fci - 		if(-yot- n=%[; /* ]me_cost) {
			if(E;c				 		            l pioc fing%s frae %d mu   	i__E *f__	i__E_POS_=r xlfdnant255		}
	}
	rse if(lenNCMP(str, "ENDFOING ") {
		if(curanf(str+clENDFOING ")", 1, &tenc;
s[; /* ]0; 1
					fprintf(stderr,*      weird FOING ")"te.
	t */
atae %d mu   	ieno, c			exit(1);
		}
		cl-f->fenc;
s[; /* ]st)  {
	 covermpc iitiesyrmat str			foranf(str+clENDFOING ")"-1", 1, &tenc;
s[; /* ]0;cl-f->fenc;
s[; /* ]s>xenc = 		retenc = 0;
fenc;
s[; /* ];
	rse if(lenNCMP(str, "ENDDTH_NA {
		if(curanf(str+clENDDTH_NAd		/, 1, &, ysz&)
	c!=2
					fprintf(stderr,*      weird DTH_NAdte.
	t */
atae %d mu   	ieno, c			exit(1);
		}
		cl-t- n=%[; /* ]mth} }x;
	sz*le;
sta	rse if(lenNCMP(str, "ENDBBX {
		if(curanf(str+clENDBBXd		/, d		/, 1, &, ysz&)
	, &,, yof&f)
	c!=4
					fprintf(stderr,*      weird BBXdte.
	t */
atae %d mu   	ieno, c			exit(1);
		}
		cl-p=0;
l piocz+1)*)
	c;cl-f->p=0;
={
			if(E;c				 		            l pioc fing%s frae %d mu   	i__E *f__	i__E_POS_=r xlfdnant255		}
	}
	-t- n=%[; /* ]mls *or-,, y*le;
sta	-t- n=%[; /* ]mxMin*or-,, y*le;
sta	-t- n=%[; /* ]mxMa (GEX+1)-,, y)*le;
sta	-t- n=%[; /* ]myMin*or-y, y*le;
sta	-t- n=%[; /* ]myMa (GEXy1)-,, y)*le;
sta	rse if(lenNCMP(str, "ENDBITMAP {
		if(cap=0;
1					ln;
	z-1; y>=the lineoweline */
 beeirlix*/
   	rse if(lenNCMP(str, "ENDFOD< (1);(f-

	map=0;
	sta-f->p=0;
			ge->- n=%[; /* ]mlentry = 0;
		g->->- n=%[; /* ]mhs;
0;
		g->->- n=%[; /* ]mries = g->		g->-bmp_lines *(&>- n=%[; /* ],ale_ex, p, xsz, ysz, xoff, yoff)
	c	g->-e(ampb);
sta	* remember theinstrinc intta x, in vtll be%fixera*clo			foraths;

[; /* ]st >- n=%[; /* ]mries = 	g->->- n=%[; /* ]mries = g->		g	if(c !aths;

[; /* ]					*>- n=%[; /* ]mttf_hs;
 = 1;
						e
					*s>- n=%[; /* ]mttf_hs;
 = 1;
0	}
		cl-> /* 
				rse if(lenmap=0;
		if(curgl ln<0
					fprintf(stderr,*      map */
isngest
r nick 		/es */
atae %d mu   	i, xofeno, c			exit(1);
		}
		cif(c
	sta-p=&p[y*xgl lnz+x]]++,sz=p+; x+ta-le(( cen; i
			cge =e.
	v++]		if(c !!isxdig1);c)
						fprintf(stderr,*      -
 *hix*dig1)einsmap */
atae %d mu   	ieno, c			exiit(1);
			}
		}
	(curg<='9						*c-='0'		else if(				*c= exeowel =)-'a'+1		g	if((p = , *=p+4++,<,sz (c ,<,, *; c<< 1
					**p= c;
c=geIS_8 /* 0; p		}
		cl-f->,<,sz
					fprintf(stderr,*      map */
e %d too lonshor/
atae %d mu   	ieno, c			exit(1);
		}
		cl-gl ln
				return 0;
}

/*
 * Pard the the frapossi x, inmat st of ab the limphs
 */

static inten*v
dglyphs( GL
	PH *glyph_list);
{
	sta i, c;
	PH *glyp	if(!LE_glyphs = 				urn 0;;/* thes 2 *m by extdle_glyphs(
	i)rough hertics */

#d	phs = 0;
ph_list);
char /* p;
		 skip unt end mpsyrph_lid par.noderf

			*inputitial the sub mpsyrph_lid par.noderf

			*(i=0; i<2; i++)
							g&xf->- n=%[i]		iflasts 0;
					lasth} }x;
t.bbox[2], &				lasxMin*or					lasyMin*or				retg&xf->- n=%[
	intname, g&xf".noderf"intnamxMa (GEt.bbox[2], &*4/5intnamyMa (GEt.bbox[2],3&*4/5intnamries = g->lashs;
0;
lastentry = 0;
		g-/ake 2 plateook wela bl */
squa*/
				rmoveto(g, -1e0.01e0.0	for(lineto(g, fsc0.01e(ble x,)namyMa 	for(lineto(g, fsc(ble x,)namxMa 1e(ble x,)namyMa 	for(lineto(g, fsc(ble x,)namxMa 1e0.0	for(lineto(g, fsc0.01e0.0	forlosepath(g);
				aths;

[0]g->entries;
		g-namries = g->0	g-namttf_hs;
 = 1;
4;/* g&xf->- n=%[1	intname, g&xf".null"intnamxMa (GEnamyMa (GE0	g-namttf_hs;
 = 1;
0	if(!LEdfile(
	F_file;
s,tdle_glyphs(
	 fab0coiCAVE;c						                  s not sta       e subFONT"))ne\n", 
d xel_sisa int xsz_glyphs = 0;
1

/*
 * ParO butge a  parsare a lreplan 0;
inmat st of the stam   edrit,
* RetMayint outor in  parwang <0,messag
 */

 Esis EOFor in./

static inten*v
nfont(chahar *fmt;e, lihar *fmt */
updanu*clonow

st
	struct line *cl;
	cha i, c;
l	if(!L
c=_file;
s0;
fefon(me, cha"r);(ft) L);
	oiCAVE;c						             Can stao butg;
s0'%s'   	ife);
			ex_sisa int xse {
			c WARN ")_2 E;c						        Pessing */
g;
s0n", linfe);
			e	cifeno, c0;
1

or(cl = header;%cl->name != 0; cl++) {

l->flags |= ~GEXSEEN;
		if!LEdfile(
	F_file;
s,tdle_glyder;%c fab0coiCAVE;c						                  s not sta       e subRS "),inition */, 
d xel_sisa int xsz(cl = header;%cl->name != 0; cl++) {
		if(str ->flags & IS_T_SEE|IS) (c !->flags & IS_SEEN) {
	
					fprintf(stderr,**** unemard torydperty %s atiot stand, e the input file\n", 
							>name);
		 covename != hwela ce */
the con ys				else(1);
		}
		cif(skipe cirfew,iniaul*/
					str !->flags & IS_SEEN) {
	
					fcl->fla0], cft) et.underline_thickness} }
						fp.underline_thickness} }1;
						rse if(len>fla0], cft) et.underline_thiition} }
						fp.underline_thiition} }(GEt.bbox[2],1 halp.underline_thickness} }			cl-- (el_size} }firs.bbox[2],3&)					rse if(len>fla0], cft) et.undender} }
						fp.undender} }(GEt.bbox[2], &halp.undx[0], &					rse if(len>fla0], cft) et.undcender} }
						fp.undcender} }(GEt.bbox[2], &					r}
	}
	rcifyphs ( v+;
		 skiaddd mpsyrph_lid par.noderf

			*inpt-prcessing */
curvoms.
  the the argdifence ton the fraric witmat st/
				t.bbox[2], &haGEt.bbox[2], &			s.bbox[2],3&haGEt.bbox[2],1
				le the;
	000/el_size;
st XXX nee/
	chacurae th*el_size} }f< 950coiCAVle the;
	;CAVle thternal;

e;
	;CAVp.underits_ty _by =xel_size;
sta xse {
			c le thternal;

e;
0;CAVp.underits_ty _by =xae th*el_size} }		for(.underline_thiition} }(*= le;
sta	-p.underline_thickness} }1*= le;
sta	-p.undender} }(*= le;
sta	-p.undcender} }(*= le;
sta	-pi=0; i<2; 4++)
						t.bbox[2],i](*= le;
sta		free.bboital c_ayph 0;

.0	if!LEcing} } 0 || inpt-psi xn int staf */
					||uchipty Ecing} })) = 0; 'P'* musin  pyng but-
 *pertor/il symoENDFg.bbois_ed by_ph(gee;
	;CAe
					g.bbois_ed by_ph(gee;
0	if(!LEt.name_copyright} }ULL */)			g.bboe_copyright} }&xf""int	*inpcre the firs cope != oENDlstr+cllon(m.name_family} }
				+ (m.name_famle} }?r+cllon(m.name_famle} }) : 				r+ (mdth} }?r+cllon(mdth} }) : 				r+ +cllon("Oblique")1; /*if(!LE( m.name_fami cop= l pioczl
	
ULL */)oiCAVE;c				 		            l pioc fing%s frae %d mu   	i__E *f__	i__E_POS_=r xldnant255		}
}tructcpy(m.name_fami co, m.name_family} }
	if!LEmdth} } (c uctcmpEmdth} }   Nal re);(f-

	uctcat(m.name_fami co, mdth} });t xsz, nm.name_famle} } (c uctcmpEm.name_famle} }   Medium);(f-

	uctcat(m.name_fami co, m.name_famle} })	}
}truch(ge-chipty Ect} })) = d-

e GE_'O':

	uctcat(m.name_fami co, "Oblique")r xlak;
				e GE_'I':

	uctcat(m.name_fami co, "Ital c")r xlak;
					free.bboe_famps(GEt.bboe_fami co;ree.bboe_fams ou} }(GE"1.0"*if(!LErset_reg} } (c rset_enc} }
	(c !uctcmpErset_reg} }, "iso10646") (c !uctcmpErset_reg,
	/E"1"			counicode = 0;
/*if(!LE( menc;
sc;
	 pioczyphs,
	/				}
		ntenc;
s
	
ULL */)oiCAVE;c				 		            l pioc fing%s frae %d mu   	i__E *f__	i__E_POS_=r xldnant255		}
}trpi=0; i<2; yphs;
st+)
					fenc;
s[= abs
			e!LE( aths;

c;
	 pioczyphs,
	/				}
		naths;


	
ULL */)oiCAVE;c				 		            l pioc fing%s frae %d mu   	i__E *f__	i__E_POS_=r xldnant255		}
}t/*
 * ParCepat menc*/

 Esis EOFor in./

static inten*v
sefont( vooien*v{
	sta  nmsefonF_file;
s fab0coiCAVWARN ")_1 E;c						        Er insen a csefo the conge a q?r , ire thd, 
d xe}t/*
 * ParGehe conber of genths ( vin menc*/

static int
hannglyphs ( vooien*v{
	stalan 0;
yphs;
sta/*
 * ParGehe conbs,
	 the glyphs
 ** Returns -1 0 the sizbs,
	 w are sn(ge we -
 *zero the sizmenc
prefeovidnot srph_lidbs,
	*/

static int
hannmes( GL
	PH *glyph_list);
{
	stadglyphs( GLph_list);

/*turn 0;
}

/*
 * ParGehe conoht}i erroding, i the font fi * Stourns -1 1e theife conoht}i erroding, i iotUode = , 2eife co Stooht}i erroding, i ioter dir16-bit, 0 the8-bit*/

static int
hannm( GL
	PH *glyph_list);
int (*scoding, innt (*scmap);
{
	sta i, c, s map, e*if(!LEunicode = 0ff->orce=0;

oublenie;
	;CAe
					blenie;
0

or(cl ; i<2; yphs;
st+)
		oiCAVe0;
fenc;
s[i]		ifdy >leni					e0;
code = g} v_eookup(ec;cl-f->e>&& (c e<ENCTABSZ (c eding, i[e]st)  {
				eding, i[e]st c;
	}if(!LEunicode = 				urn 0;
	;CAe
		(lenenc = 0> 255				urn 0;
2;CAe
					urn 0;
}

/*	
 * ParGehe conge a rics fm/
static inten*vp
etrics( sttruct lint_metrics *fm);
{
	sta);
(GEt.bb

/*
 * ParGehe conhs;
0call_mers sym thearph_li./

static inten*v
ath( inta i, phno, GL
	PH *glyph_fst);
{
	stadglyphs( GLph_fst);

/*tph_fst);
[phno, G]mries = g->aths;

[phno, G]			aths;

[phno, G]e;
0

/*
 * ParGehe conning,
}ta to./

static inten*v
ning( GL
	PH *glyph_list);
{
	stadgn 0;; no symning,
}tin  fon}
